define([
    'ko'
    ], function (ko) {
        return {
            isLoading: ko.observable(false)
        }
    }
);