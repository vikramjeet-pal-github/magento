<?php
namespace Grazitti\Warranty\Controller\Index;

use Magento\Framework\App\Action\Context;
 
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;

class Addtocart extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
    protected $_cart;
    protected $_productRepositoryInterface;
    protected $_url;
    protected $_responseFactory;
    protected $_logger;
    protected $resultJsonFactory;
    
    public function __construct(
        Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_cart = $cart;
        $this->_productRepositoryInterface = $productRepositoryInterface;
        $this->_responseFactory = $responseFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_url = $context->getUrl();
        $this->_logger = $logger;
        parent::__construct($context);
    }
 
    public function execute()
    {
        //header("Content-type:application/json");
        $sku = $this->getRequest()->getParam('sku');

        $_product = $this->_productRepositoryInterface->get($sku);
        $params =  [
            'product' => $_product->getId(),
            'qty' => 1,
            'price' => $_product->getPrice(),
            
        ];
        
        try {
            $this->_cart->addProduct($_product, $params);
            if ($this->_cart->save()) {
                $response =  ['success' => true];
            } else {
                $response =  ['success' => false];
            }
        } catch (exception $e) {
            $response =  ['success' => false, 'message' => $e->getMessage()];
        }
        
        $resultJson = $this->resultJsonFactory->create();
        return $resultJson->setData($response);
    }
}
