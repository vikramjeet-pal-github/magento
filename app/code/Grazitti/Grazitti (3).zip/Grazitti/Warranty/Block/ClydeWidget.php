<?php
/**
 * Google Tag Manager block
 */
namespace Grazitti\Warranty\Block;

use \Magento\Catalog\Model\Product;

class ClydeWidget extends \Magento\Framework\View\Element\Template
{

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $registry,
        Product $product,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_registry = $registry;
        $this->_product = $product;
    }

    public function getCartSKUs()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $cart = $objectManager->get(\Magento\Checkout\Model\Cart::class);

        // retrieve quote items collection
        $itemsCollection = $cart->getQuote()->getItemsCollection();
        
        // get array of all items what can be display directly
        $itemsVisible = $cart->getQuote()->getAllVisibleItems();
        
        // retrieve quote items array
        $items = $cart->getQuote()->getAllItems();
        
        $array = [];
        foreach ($items as $item) {
            $array[] = $item->getSku();
        }

        return $array;
    }

    public function getCurrentProduct()
    {
        $product = $this->_registry->registry('current_product');
        return [$product->getSku()];
    }
    
    public function isProductExist($sku)
    {
        if ($this->_product->getIdBySku($sku)) {
            return true;
        }

        return false;
    }
}
