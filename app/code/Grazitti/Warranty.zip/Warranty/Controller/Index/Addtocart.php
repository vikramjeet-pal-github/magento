<?php
namespace Grazitti\Warranty\Controller\Index;
use Magento\Framework\App\Action\Context;
 
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;

class Addtocart extends \Magento\Framework\App\Action\Action

{
    protected $_resultPageFactory;
    protected $_cart;
    protected $_productRepositoryInterface;
    protected $_url;
    protected $_responseFactory;
    protected $_logger;
 
 
    public function __construct(
        Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Psr\Log\LoggerInterface $logger
        )
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_cart = $cart;
        $this->_productRepositoryInterface = $productRepositoryInterface;
        $this->_responseFactory = $responseFactory;
        $this->_url = $context->getUrl();
        $this->_logger = $logger;
        parent::__construct($context);
    }
 
    public function execute()
    {       
        $sku = $this->getRequest()->getParam('sku');
        $_product = $this->_productRepositoryInterface->get($sku);
        $params = array (
            'product' => $_product->getId(),
            'qty' => 1,
            'price' => $_product->getPrice(),
            
        );
 
        try{
            $this->_cart->addProduct($_product, $params);
            if($this->_cart->save())
            {
                print json_encode(['success' => true]);
            }
            else
            {
                print json_encode(['success' => false]);
            }
        }
        catch(exception $e)
        {
            print json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        header("Content-type:application/json");
    }
 
}