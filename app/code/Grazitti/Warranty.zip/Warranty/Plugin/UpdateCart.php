<?php
namespace Grazitti\Warranty\Plugin;
use \Magento\Framework\Message\ManagerInterface ;

class UpdateCart 
{
    /**
     * @var ManagerInterface
     */
    protected $_messageManager;

    /**
     * @var \Magento\Quote\Model\Quote
     */
    protected $quote;

    /**
     * Plugin constructor.
     *
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Framework\App\Request\Http $request,
        ManagerInterface $messageManager
    ) {
        $this->quote = $checkoutSession->getQuote();
        $this->_messageManager = $messageManager;
		 $this->request = $request;
    }

    /**
     * @param \Magento\Checkout\Model\Cart $subject
     * @param $data
     * @return array
     */
    public function beforeupdateItems(\Magento\Checkout\Model\Cart $subject,$data)
    {
		
      $cartData = $data;
      if (is_array($cartData)) {
			$quote = $subject->getQuote();
			$quoteItems = $quote->getAllVisibleItems();
			$productWarranty=array();
			$productSkus=array();
			foreach($quoteItems as $item) {
				$productSku = $item->getProduct()->getSku();
				$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
				$associatedProductSkuMain = $objectManager->get('Magento\Catalog\Model\Product')->load($item->getProduct()->getId());
				$associatedProductSku = $associatedProductSkuMain->getAssociatedProductSku();
				$productSkus[$productSku] = $item->getId();
				if($associatedProductSku != ''){
					$productWarranty[$associatedProductSku] = $item->getId();
				}
			}
			foreach($productWarranty as $key=>$warranty){
				if(isset($productSkus[$key])){
					if($cartData[$warranty]['qty'] > $cartData[$productSkus[$key]]['qty']){
						$cartData[$warranty]['qty'] = $cartData[$productSkus[$key]]['qty'];
						$cartData[$warranty]['before_suggest_qty'] = $cartData[$productSkus[$key]]['qty'];
					}
				}else{
					$cartData[$warranty]['qty'] = 0;
					$cartData[$warranty]['before_suggest_qty'] = 0;
				}
			}
			
		}
		
		return [$cartData];
    }
	
	public function beforeremoveItem(\Magento\Checkout\Model\Cart $subject)
    {
		
	  $params = $this->request->getParams();
	  if (isset($params['id'])) {
			$quote = $subject->getQuote();
			$quoteItems = $quote->getAllVisibleItems();
			$productWarranty=array();
			$productSkus=array();
			foreach($quoteItems as $item) {
				$productSku = $item->getProduct()->getSku();
				$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
				$associatedProductSkuMain = $objectManager->get('Magento\Catalog\Model\Product')->load($item->getProduct()->getId());
				$associatedProductSku = $associatedProductSkuMain->getAssociatedProductSku();
				$productSkus[$productSku] = $item->getId();
				if($associatedProductSku != ''){
					$productWarranty[$associatedProductSku] = $item->getId();
				}
			}
			foreach($productSkus as $key=>$warranty){
				if($warranty == $params['id']){
					$quote->removeItem($productWarranty[$key]);
				}
			}
			
		}
	}
}
