<?php
/**
 * Copyright © 2020 Grazitti. All rights reserved.
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Grazitti_Maginate',
    __DIR__
);
