<?php

namespace Grazitti\Warranty\Api;

interface SetAddressInterface
{
 /**
     * 
     * @param string $entity_id
     * @param string $parent_id
     * @param string $postcode
     * @return string
     */
    public function setAddress($entity_id,$parent_id,$postcode);

    

}