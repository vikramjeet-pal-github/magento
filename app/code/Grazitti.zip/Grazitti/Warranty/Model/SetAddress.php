<?php
 
namespace Grazitti\Warranty\Model; 
 
class SetAddress implements \Grazitti\Warranty\Api\SetAddressInterface
{

    
    /**
     * 
     * @param string $entity_id
     * @param string $parent_id
     * @param string $postcode
     * @return string
     */
    public function setAddress($entity_id,$parent_id,$postcode){
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $orderAddress = $objectManager->create('Magento\Sales\Model\Order\Address');
        $collection = $orderAddress->getCollection();
        $collection->addFieldToFilter('entity_id',['eq'=>$entity_id]);
        $collection->addFieldToFilter('parent_id',['eq'=>$parent_id]);

        foreach($collection as $item)
        {                       
           $item->setPostCode($postcode);

        }
        $collection->save();
        return "Order Data Updated sucessfully";
        
    }
    
}